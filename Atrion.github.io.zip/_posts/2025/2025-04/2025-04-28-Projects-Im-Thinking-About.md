---
layout: post
title: "Projects I'm Thinking About"
date: 2025-04-28 1:2:00 -0400
categories: [Projects]
tags: [projects, ideas, planning]
author: Atrion Darnay
---

Here's a few things on my mind lately:

- Expanding this blog little by little.
- Finding a way to organize my older writings and poems.
- Building some templates to aid my personal Bible study.
- ??? Things

Some of these will happen. Some might get abandoned. But that's life, right?
