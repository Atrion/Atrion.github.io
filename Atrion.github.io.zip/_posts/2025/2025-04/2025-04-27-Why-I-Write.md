---
layout: post
title: "Why I Write (Even When I'm Not Sure)"
date: 2025-04-27 15:45:00 -0400
categories: [Personal]
tags: [writing, personal, beginning]
author: Atrion Darnay
---

Writing has always been a strange thing for me.

Sometimes I write because I feel like I have something to say. Sometimes I write just because the page is there, and it's empty, and it feels wrong to leave it blank.

I don't know where this site will go. I don't even know what exactly it will become. But I'm starting it because I want to try. To share. To build. To maybe say something that matters, even if it's just to myself.

We'll see where it leads.
