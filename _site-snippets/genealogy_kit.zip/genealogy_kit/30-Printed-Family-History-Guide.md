---
title: "Printed Family History — Step‑by‑Step"
tags: [book, print, rootsmagic, gedcom, odt, pdf, styling]
---

# Printed Family History — Step‑by‑Step

Two proven routes: a fast **RootsMagic Publisher** workflow, and a high‑control **GEDCOM → ODT** pipeline.

## Route 1 — RootsMagic **Publisher** (fastest)

**Prepare**
- Sync media via **TreeShare** (see [[20-Ancestry-Media-Download.md]]).
- Run a data pass: fix names (consistent surname casing), dates (DD Mon YYYY), and places (standardized hierarchy).

**Build the book**
1. In **RootsMagic**: **Publish** → **Books** → **New**.  
2. Add sections (commonly):  
   - Title page, Table of Contents  
   - **Ancestor Narrative** (choose root person, generations, include notes/sources)  
   - **Descendant Narrative** (optional)  
   - Lists (Surname Index, Place Index), Source List, Photo Pages (optional)
3. **Options** to check:  
   - Include **private notes**? (usually **No**)  
   - **Exclude living** or privatize details  
   - Place/name formats; fact sentences; endnotes vs footnotes
4. **Generate DOCX**. Open in Word/LibreOffice for styling.
5. Apply **styles** (H1/H2), fix page breaks, ensure image captions, and add front/back matter (Foreword, Acknowledgements, Bibliography).
6. **Export PDF** with print settings (embed fonts, 300 DPI).

**Quality checks**
- Random‑sample facts vs. sources.  
- Ensure images are at least **300 DPI** at print size.  
- Run spell/grammar pass, verify indexes and TOC.

---

## Route 2 — GEDCOM → ODT (high control)

**Why**: maximum control over typography and chapter structure; repeatable automation.

**Steps**
1. **Export GEDCOM** from RootsMagic (UTF‑8, include notes/sources, apply living‑person privacy).  
2. Install **Python 3.11+** and `pip install ged2doc`.  
3. Run conversion (example):  
   ```bash
   ged2doc --input tree.ged --output out/book.odt --photos ./media --lang en
   ```
4. Open `book.odt` in LibreOffice/Word; apply your styles and layout.  
5. Insert charts (optional): either screenshots from RM/Gramps or LaTeX‑generated diagrams saved as images.  
6. Export to **PDF**.

**Tips**
- Keep a `styles.odt` template with your headings, caption, and table styles.  
- Use consistent **person key** (RIN/I‑numbers) for cross‑referencing appendix material.  
- Maintain a simple **change log** as you iterate.

---

## Front/back matter suggestions
- **Foreword / Preface** — purpose and scope.  
- **Methodology** — sources used, standards, and limitations.  
- **Editorial policy** — naming, date, and place conventions.  
- **Acknowledgements** — family contributors, archives.  
- **Bibliography** — books, records, websites.  
- **Index** — names and places.

---
