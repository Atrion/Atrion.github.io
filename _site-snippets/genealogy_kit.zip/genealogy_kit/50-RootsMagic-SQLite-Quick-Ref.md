---
title: "RootsMagic + SQLite — Read‑Only Inspection (Safe Practices)"
tags: [rootsmagic, sqlite, sqlite-utils, safety, backup]
---

# RootsMagic + SQLite — Read‑Only Inspection (Safe Practices)

**Rules of the road**
- **Work on a copy** of your `.rmtree`/`.rmgc` file.  
- Prefer **read‑only** queries for exploration; make fixes in the RootsMagic UI unless you fully understand schema effects.  
- Back up before every major operation.

## Quick start with `sqlite-utils`
Install: `pip install sqlite-utils`

**Examples (read‑only)**
```bash
# List tables
sqlite-utils tables tree.rmtree

# Row counts by table
sqlite-utils rows tree.rmtree | head -n 50

# Sample people records
sqlite-utils query tree.rmtree "
  SELECT PersonID, Surname, Given, Sex
  FROM PersonTable
  ORDER BY Surname, Given
  LIMIT 20;
"
```

## What to look for
- Duplicate individuals, orphaned citations, missing media files.  
- Non‑standard date/place strings that cause ugly sentences in narratives.  
- Overuse of custom facts that don’t map well across apps (prefer standard facts).

> If you must script changes, do so with explicit backups and verify every step inside RootsMagic afterward.

---
