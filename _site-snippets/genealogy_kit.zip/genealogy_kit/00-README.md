---
title: "Genealogy Publishing Kit (Ancestry + RootsMagic)"
tags: [genealogy, rootsmagic, ancestry, gedcom, book, website, obsidian]
created: 2025-09-25
version: "1.0"
---

# Genealogy Publishing Kit (Ancestry + RootsMagic)

This kit consolidates prior guidance and adds **step‑by‑step instructions** for two deliverables:
1) a **printed family history**, and  
2) a **public or private website** for your tree.

### A) Printed book (fastest — RootsMagic Publisher)
1. In **RootsMagic** open your working file → **Publish** → **Book** (Publisher).
2. Add sections (Ancestor/Descendant Narrative, Title page, TOC, Indexes, Sources).
3. Configure options: name formats, places, sources, notes, privacy filters.
4. **Generate DOCX** → edit in Word/LibreOffice (style headings, images, captions) → **Export PDF**.
5. Optional: run a content pass for consistency (names/dates/places) before final PDF.

### B) Printed book (high control — GEDCOM → ODT/PDF)
1. **Export GEDCOM** from RootsMagic.
2. Use **ged2doc** (Python) to produce **ODT** or **HTML**.
3. Open ODT in LibreOffice/Word → apply house styles, insert charts/images → Export PDF.

### C) Website (collaborative — webtrees)
1. Install webtrees on a PHP/MySQL host.
2. Import GEDCOM, set **privacy for living**, choose theme, enable user accounts.
3. Point your domain to the host.

### D) Website (modern, API‑ready — Gramps Web)
1. Deploy the Docker compose from this kit (in the guide) to a small VPS or NAS.
2. Import a Gramps archive or GEDCOM (from RootsMagic export via Gramps).
3. Add reverse proxy + HTTPS and share read‑only URLs with family.

### E) Website (simple, static — GitHub Pages)
1. Export **Narrative Web** from Gramps or a RootsMagic narrative/HTML.
2. Commit to a repo `/docs` folder or `gh-pages` branch.
3. Enable **GitHub Pages**; optional workflow included in the guide.

> **Tip:** Always **work on a copy** of your RootsMagic file before bulk operations.

---
