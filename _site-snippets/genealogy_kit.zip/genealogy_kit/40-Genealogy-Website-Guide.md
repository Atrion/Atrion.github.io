---
title: "Genealogy Website — webtrees, Gramps Web, or GitHub Pages"
tags: [website, publishing, webtrees, gramps, docker, github-pages]
---

# Genealogy Website — webtrees, Gramps Web, or GitHub Pages

Choose the hosting style that matches your goals and comfort level.

## Option A — **webtrees** (collaborative PHP app)
**When to choose**: you want a classic, collaborative online tree with user accounts and granular privacy.

**Checklist**
1. Host with PHP 8.x and MariaDB/MySQL (shared hosting is fine).  
2. Create a database and user; note credentials.  
3. Upload webtrees files; visit the installer.  
4. Create admin account; import **GEDCOM** (exported from RootsMagic).  
5. Configure **privacy** (hide living, limit dates), theme, modules, and backups.  
6. Point your domain (A/AAAA/CNAME) to the host and enable HTTPS.

## Option B — **Gramps Web** (Docker; modern UI + API)
**When to choose**: you prefer a modern stack, API access, and easy container updates.

**docker‑compose.yaml (example)**
```yaml
version: "3.8"
services:
  grampsweb:
    image: ghcr.io/gramps-project/grampsweb:latest
    ports: ["8000:5000"]
    volumes:
      - ./data:/app/data
      - ./media:/app/media
    environment:
      - GRAMPSWEB_AUTH=public  # or 'login'
      - GRAMPSWEB_TITLE=Family Tree
    restart: unless-stopped
```
**Steps**
1. Save the file as `docker-compose.yaml`; run `docker compose up -d`.  
2. Open `http://YOURHOST:8000` and follow prompts.  
3. Import a Gramps archive or GEDCOM (from RootsMagic export).  
4. Put **Caddy/Traefik/nginx** in front for HTTPS + a friendly domain.

## Option C — **Static site** (GitHub Pages)
**When to choose**: you want a simple, low‑maintenance, read‑only site.

**Routes**
- **Gramps Narrative Web**: Tools → Reports → Web → export HTML+assets; commit to repo.  
- **RootsMagic narrative export**: export narrative pages; commit to repo.

**GitHub Pages (docs folder)**
1. Create a repo, add your exported site under `/docs`.  
2. In repo **Settings → Pages**, select **Deploy from /docs**.  
3. Visit `https://USERNAME.github.io/REPO/`.

**Optional GitHub Actions (build and deploy)**
```yaml
name: Deploy static site to Pages
on:
  push:
    branches: [ main ]
permissions:
  pages: write
  id-token: write
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/upload-pages-artifact@v3
        with:
          path: docs
      - uses: actions/deploy-pages@v4
```

**Best practices**
- Exclude or anonymize **living persons**.  
- Optimize images (long edge 1600px) to keep the site fast and within repo limits.  
- Add a simple top nav and a `README.md` explaining source/updates.

---
