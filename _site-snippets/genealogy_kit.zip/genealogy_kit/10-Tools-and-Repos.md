---
title: "Tools & Repos That Pair Well With Ancestry/RootsMagic"
tags: [genealogy, tools, repos, gedcom, dna, rootsmagic, gramps, webtrees]
---

# Tools & Repos That Pair Well With Ancestry/RootsMagic

Below are established, widely used projects and why they’re useful with Ancestry/RootsMagic workflows. Prefer standard **GEDCOM** interchange for maximum portability.

## Desktop / Server Apps
- **Gramps** — Open‑source desktop genealogy with powerful reports, Narrative Web export, and plugins. Great as a second workbench alongside RootsMagic.
- **Gramps Web** — Web UI/API on top of Gramps data. Ideal for a private family site; deploy via Docker.
- **webtrees** — Mature PHP web app for collaborative online trees; imports standard GEDCOM; fine‑grained privacy controls.

## Standards & Libraries
- **FamilySearch GEDCOM (current spec)** — Track changes in the standard to keep exports/imports healthy.
- **parse-gedcom / read-gedcom (JavaScript)** — Fast ways to parse GEDCOM in Node scripts.
- **python-gedcom (Python)** — GEDCOM parsing for audits, transforms, and CSV summaries.

## RootsMagic & Database Utilities
- **sqlite-utils (Python CLI/lib)** — Inspect SQLite safely (RootsMagic uses SQLite under the hood). Great for read-only analysis on copies.
- **RootsMagic-focused scripts** — Community utilities (Python/SQL) that fix common pain points (citations, color groups, fact conversions). Use cautiously, and only on backups.

## DNA & Data Cleanup
- **snps (Python)** — Read/clean/filter raw genotype files from DTC providers (e.g., AncestryDNA).
- **OpenRefine** — GUI powerhouse for cleaning names/places/sources after exporting to CSV/TSV.

> **Why these**: longevity, active maintenance, clear docs, and a demonstrated user base across the genealogy community.

---

## Suggested combinations

- **Publish + collaborate**: RootsMagic → GEDCOM → **webtrees** or **Gramps Web**.
- **Printed book (fast)**: RootsMagic **Publisher** → DOCX → PDF.
- **Printed book (custom)**: RootsMagic GEDCOM → **ged2doc** → ODT → style → PDF.
- **Data QA**: export GEDCOM/CSV → **python-gedcom**/**sqlite-utils** checks → fix in RM UI.
- **DNA notes**: download AncestryDNA raw data → **snps** summaries → attach notes to people.

---
