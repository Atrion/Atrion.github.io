---
title: "Ancestry Media: Safest Ways to Get Local Copies"
tags: [ancestry, media, download, treeshare, rootsmagic, tos]
---

# Ancestry Media: Safest Ways to Get Local Copies

## Recommended (ToS‑compliant): RootsMagic **TreeShare**
1. Open **RootsMagic** (Windows).  
2. **File → Create/Open** your working file.  
3. **Publish** → **Ancestry TreeShare** → sign in to Ancestry.  
4. Choose your Ancestry tree and **download/sync**.  
5. RootsMagic creates/maintains a local **media folder** (alongside your `.rmtree`) and saves images/documents referenced by your tree.

**Tips**
- After syncing, run a pass to **rename files** to your convention (e.g., `YYYY‑MM‑DD_place_event_person.jpg`).  
- Use RM’s **Media** tab to spot missing links.  
- Keep the Ancestry and RM sides in sync; prefer edits in one place per session to reduce conflicts.

---

## Post‑download housekeeping
- **De‑duplication:** hash or visually review near‑duplicates before book/site assembly.  
- **Derivative sizes:** keep **originals** plus **web‑optimized** copies (e.g., 1600px long edge, 72–110 DPI) for your website.  
- **Captions & sources:** ensure every image has a **caption** and **source citation** in RM (these flow into reports).

---
